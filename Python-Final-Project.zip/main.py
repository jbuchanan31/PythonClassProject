def main():
  # Initialize an empty list to store daily sales
  sales = []

  # Prompt the user to enter sales for each day of the week
  for day in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]:
      sales.append(float(input(f"Enter sales for {day}: ")))

  # Calculate the total sales for the week
  total_sales = sum(sales)

  # Display the total sales for the week
  print(f"Total sales for the week: {total_sales}")

if __name__ == "__main__":
  main()